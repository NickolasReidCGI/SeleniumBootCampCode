
package practiceTestCases;
 
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By; 
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
 
//http://toolsqa.com/selenium-webdriver/switch-commands/
 
public class ScreenSwitchingDemo {
 
		
 
		public static void main(String[] args) throws InterruptedException {

			WebDriverManager.chromedriver().setup();
	      SwitchScreenDemo();
	     //   alertDemo();
	}
		
		
		public static void SwitchScreenDemo() throws InterruptedException{
	        // Launch the URL
		
			 WebDriver driver = new ChromeDriver();
	        driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");
 
	        // Store and Print the name of the First window on the console
	        Thread.sleep(1000L);
	        String handle= driver.getWindowHandle();
 
	        System.out.println(handle);
 
	        // Click on the Button "New Message Window"
 
	        driver.findElement(By.id("button1")).click();
	        Thread.sleep(1000L);
	        // Store and Print the name of all the windows open	              
 
	        Set handles = driver.getWindowHandles();
 
	        System.out.println(handles);
 
	        // Pass a window handle to the other window
 
	        for (String handle1 : driver.getWindowHandles()) {
 
	        	System.out.println(handle1);
	        	 Thread.sleep(1000L);
	        	driver.switchTo().window(handle1);
	        	 Thread.sleep(1000L);
	        	}
 
	        
	        System.out.println(driver.findElement(By.xpath(".//span[@style='color: #3366ff; font-size: 130%;']")).getText());
	        
	        // Closing Pop Up window
 
	        driver.close();
 
	        // Close Original window
 
	        driver.quit();
	        Thread.sleep(1000L);
	        System.out.println("Success");
	        
	        
		}
		
		public static void alertDemo() throws InterruptedException{
			

	    
			 WebDriver driver = new ChromeDriver();
	        // Put an Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception
 
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 
	        // Launch the URL
 
	        driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");
 
	        // Click on the Button "Alert Box"
	        
	        WebElement element = driver.findElement(By.id("alert"));

	      //  element.click();
	    //    Actions actions = new Actions(driver);
	    //   Thread.sleep(1000L);
	    //    actions.moveToElement(element).click().perform();
	    //    Thread.sleep(1000L);
	      //  driver.findElement(By.id("alert")).click();
 
	        // Switch to JavaScript Alert window
	       // Thread.sleep(1000L);
	        //Alert myAlert = driver.switchTo().alert();
	        //Thread.sleep(1000L);
	        // Accept the Alert
 
	       // myAlert.accept();
 
	        // Close Original window
 
	        
	        JavascriptExecutor jse = (JavascriptExecutor)driver;
	        Thread.sleep(1000L);
	        jse.executeScript("newAlert()", element); 
	        Thread.sleep(1000L);
	        Alert myAlert = driver.switchTo().alert();
	        Thread.sleep(1000L);
	        myAlert.accept();
	       
	        Thread.sleep(1000L);
	        driver.close();
		}
 
}